'''
#################################################################################################
The software is developed by Rahul Bhowmik of Polaron Analytics 
For any questions contact via email: rahulbhowmik@polaronanalytics.com or bhowmikrahul@gmail.com
#################################################################################################
This software is distributed under the GNU General Public License.
#################################################################################################
'''

import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import make_scorer
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


data_read = pd.read_csv("name.csv")
data_read.drop(['name','Tg', 'Cp_KJ/Kg-K', 'Cp_J/mol-K'], axis = 1, inplace = True)

data_copy = data_read

features = ['C1','C2','C3','C4','O1','O2','O3','N1','H1','H2','H3','H4','H5','H6','H7','H8','F','Cl','S','Si']  

# Separating out the features
x = data_copy.loc[:, features].values

x_scaled=StandardScaler().fit_transform(x)  ### scaling out the variables

pca = PCA(n_components=9)

PC = pca.fit_transform(x_scaled)

variance = pca.explained_variance_ratio_
variance_cumulative = pca.explained_variance_ratio_.cumsum()

df2 = pd.DataFrame(variance)
df2.to_csv('variance_name.csv')

df3 = pd.DataFrame(variance_cumulative)
df3.to_csv('variance_cumulative_name.csv')

comp = pca.components_
df4 = pd.DataFrame(comp, columns = ['C1','C2','C3','C4','O1','O2','O3','N1','H1','H2','H3','H4','H5','H6','H7','H8','F','Cl','S','Si'])
df4.to_csv('components_name.csv')

print(pca.explained_variance_ratio_)

print(pca.explained_variance_ratio_.cumsum())

