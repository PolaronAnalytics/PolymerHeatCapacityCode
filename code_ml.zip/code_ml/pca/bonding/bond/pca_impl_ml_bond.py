'''
#################################################################################################
The software is developed by Rahul Bhowmik of Polaron Analytics 
For any questions contact via email: rahulbhowmik@polaronanalytics.com or bhowmikrahul@gmail.com
#################################################################################################
This software is distributed under the GNU General Public License.
#################################################################################################
'''

import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import make_scorer
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


data_read = pd.read_csv("bond.csv")
data_read.drop(['name','Tg', 'Cp_KJ/Kg-K', 'Cp_J/mol-K'], axis = 1, inplace = True)

#data_read.drop(['Mol_Wt'], axis = 1, inplace = True)

data_copy = data_read


features = ['C3_N1','S_C2','C1_N1','C2_H4','Si_C1','S_C1','S_O1','O3_H5','C1_C1','O2_C1','C1_C3','C1_H8','C2_N1','N1_H6','C2_C2','C1_O3','Si_H1','C2_H3','C1_H2','C1_Cl','C1_H1','C2_O2','C1_C2','C2_O3','C1_F','Si_O3','C2_O1']

# Separating out the features
x = data_copy.loc[:, features].values

x_scaled=StandardScaler().fit_transform(x)  ### scaling out the variables

pca = PCA(n_components=9)

PC = pca.fit_transform(x_scaled)

variance = pca.explained_variance_ratio_
variance_cumulative = pca.explained_variance_ratio_.cumsum()

df2 = pd.DataFrame(variance)
df2.to_csv('variance_bond.csv')

df3 = pd.DataFrame(variance_cumulative)
df3.to_csv('variance_cumulative_bond.csv')

comp = pca.components_
df4 = pd.DataFrame(comp, columns = ['C3_N1','S_C2','C1_N1','C2_H4','Si_C1','S_C1','S_O1','O3_H5','C1_C1','O2_C1','C1_C3','C1_H8','C2_N1','N1_H6','C2_C2','C1_O3','Si_H1','C2_H3','C1_H2','C1_Cl','C1_H1','C2_O2','C1_C2','C2_O3','C1_F','Si_O3','C2_O1'])
df4.to_csv('components_bond.csv')

print(pca.explained_variance_ratio_)

print(pca.explained_variance_ratio_.cumsum())
