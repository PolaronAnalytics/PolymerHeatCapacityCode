'''
#################################################################################################
The software is developed by Rahul Bhowmik of Polaron Analytics 
For any questions contact via email: rahulbhowmik@polaronanalytics.com or bhowmikrahul@gmail.com
#################################################################################################
This software is distributed under the GNU General Public License.
#################################################################################################
'''

import numpy as np
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import make_scorer
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


data_read = pd.read_csv("angle.csv")
data_read.drop(['name','Tg', 'Cp_KJ/Kg-K', 'Cp_J/mol-K'], axis = 1, inplace = True)

data_copy = data_read

features = ['Cl_C1_F','F_C1_F','C2_S_C2','C2_O2_C2','H3_C2_C2','C1_C1_C3','C1_C2_C1','H2_C1_H2','Si_C1_H1','O3_Si_H1','H6_N1_C1','H1_Si_C1','C1_N1_C2','O1_S_O1','N1_C2_O1','O3_Si_C1','C2_C1_H2','S_C2_C2','C1_C2_O1','H2_C1_Cl','C2_C1_H1','C1_C1_H8','O1_C2_O3','N1_C1_H2','Si_C1_C1','Cl_C1_H8','H1_C1_H1','C1_Si_C1','Si_O3_H5','O2_C1_H2','O3_C1_H2','H8_C1_F','H1_C1_C3','F_C1_C1','C1_C3_N1','H5_O3_C1','C1_C1_S','C2_C2_O1','C2_C2_C2','O1_C2_H4','H6_N1_H6','C2_C1_O3','C1_C2_N1','C2_C2_O3','H5_O3_C2','C1_S_C1','C1_C1_N1','O2_C2_C2','O1_S_C2','C1_C1_C1','C1_C1_H2','C1_C1_O2','H6_N1_C2','C1_C1_Cl','F_C1_H2','C2_C2_H4','C1_C2_O3','C2_O2_C1','O2_C2_C1','C1_C1_O3','S_C1_H2','C1_C2_H3','C1_C2_H4','N1_C1_C2','O1_C2_O2','C1_C2_C2','C1_C1_H1','C1_C1_C2']

x = data_copy.loc[:, features].values

x_scaled=StandardScaler().fit_transform(x)  ### scaling out the variables

pca = PCA(n_components=14)

PC = pca.fit_transform(x_scaled)

variance = pca.explained_variance_ratio_
variance_cumulative = pca.explained_variance_ratio_.cumsum()

df2 = pd.DataFrame(variance)
df2.to_csv('variance_angle.csv')

df3 = pd.DataFrame(variance_cumulative)
df3.to_csv('variance_cumulative_angle.csv')

comp = pca.components_
df4 = pd.DataFrame(comp, columns = ['Cl_C1_F','F_C1_F','C2_S_C2','C2_O2_C2','H3_C2_C2','C1_C1_C3','C1_C2_C1','H2_C1_H2','Si_C1_H1','O3_Si_H1','H6_N1_C1','H1_Si_C1','C1_N1_C2','O1_S_O1','N1_C2_O1','O3_Si_C1','C2_C1_H2','S_C2_C2','C1_C2_O1','H2_C1_Cl','C2_C1_H1','C1_C1_H8','O1_C2_O3','N1_C1_H2','Si_C1_C1','Cl_C1_H8','H1_C1_H1','C1_Si_C1','Si_O3_H5','O2_C1_H2','O3_C1_H2','H8_C1_F','H1_C1_C3','F_C1_C1','C1_C3_N1','H5_O3_C1','C1_C1_S','C2_C2_O1','C2_C2_C2','O1_C2_H4','H6_N1_H6','C2_C1_O3','C1_C2_N1','C2_C2_O3','H5_O3_C2','C1_S_C1','C1_C1_N1','O2_C2_C2','O1_S_C2','C1_C1_C1','C1_C1_H2','C1_C1_O2','H6_N1_C2','C1_C1_Cl','F_C1_H2','C2_C2_H4','C1_C2_O3','C2_O2_C1','O2_C2_C1','C1_C1_O3','S_C1_H2','C1_C2_H3','C1_C2_H4','N1_C1_C2','O1_C2_O2','C1_C2_C2','C1_C1_H1','C1_C1_C2'])
df4.to_csv('components_angle.csv')

print(pca.explained_variance_ratio_)

print(pca.explained_variance_ratio_.cumsum())


